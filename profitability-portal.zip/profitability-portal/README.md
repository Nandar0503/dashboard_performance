# Profitability Command · Portal Login Firebase

Portal login (email + password) untuk dashboard profitabilitas Segmen 3, terhubung ke project Firebase **profitability-gov3**.

## Isi paket

| File | Fungsi |
|---|---|
| `public/index.html` | Portal: halaman login, reset password, dashboard, Audit Trail, Kelola Pengguna |
| `seed/dataset-segment3-ytd2026.json` | Dataset dari file Excel. Diunggah sekali ke Firestore dan **tidak** ikut di-deploy |
| `firestore.rules` | Aturan keamanan: siapa boleh membaca data, mengubah dataset, dan mengelola pengguna |
| `firebase.json`, `.firebaserc` | Konfigurasi Firebase Hosting & Firestore untuk project `profitability-gov3` |

Data dashboard **tidak tertanam di HTML**. Data hanya diambil dari Firestore setelah login berhasil dan akun memiliki peran aktif.

## Langkah setup (sekali saja)

### 1. Aktifkan layanan di Firebase Console
1. **Authentication → Sign-in method → Email/Password → Enable**.
2. **Firestore Database → Create database** (mode *production*, lokasi `asia-southeast2 (Jakarta)`).
3. **Authentication → Settings → User actions**: matikan *Enable create (sign-up)* bila tersedia. Akun cukup dibuat oleh Director dari portal.

### 2. Buat akun Director pertama
1. **Authentication → Users → Add user**: isi email dan password Anda.
2. Salin **User UID** akun tersebut.
3. **Firestore → Start collection** `users` → Document ID = UID tadi, isi field:

| Field | Tipe | Nilai |
|---|---|---|
| `name` | string | Nama Anda |
| `email` | string | Email Anda |
| `role` | string | `Director` |
| `active` | boolean | `true` |

### 3. Deploy
Butuh Node.js dan Firebase CLI.
```bash
npm install -g firebase-tools
firebase login
cd profitability-portal          # folder hasil ekstrak zip
firebase deploy --only hosting,firestore:rules
```
Portal tersedia di **https://profitability-gov3.web.app**. Konfigurasi Firebase terisi otomatis di Hosting, jadi tidak perlu menyalin apiKey.

### 4. Unggah dataset
Login sebagai Director. Karena dataset belum ada, portal menampilkan tombol unggah. Pilih `seed/dataset-segment3-ytd2026.json`, lalu dashboard terbuka.

### 5. Tambah pengguna lain
Menu **14 · Kelola Pengguna** (khusus Director): isi nama, email, password awal, peran, dan (opsional) batas pelanggan. Pengguna bisa mengganti password lewat **Lupa password?** di halaman login.

## Peran & akses

| Peran | Modul | Ubah dataset | Audit Trail | Kelola pengguna |
|---|---|---|---|---|
| Director | Semua | ✓ | ✓ | ✓ |
| Finance | Semua | ✓ | ✓ | – |
| Business Unit Head | 01–10, 12 | – | – | – |
| Analyst | 01–10, 12 | – | – | – |
| Project Manager | 01, 04, 05, 06, 08, 09, 12 | – | – | – |

## Keamanan
- Login gagal, akun nonaktif, dan sesi tanpa aktivitas selama 30 menit otomatis ditangani. Pilihan "Tetap masuk" menentukan apakah sesi bertahan setelah browser ditutup.
- Akun Firebase yang tidak punya profil `users` aktif tetap tidak dapat membaca data (diblokir oleh `firestore.rules`).
- **Batas pelanggan** pada Project Manager hanya menyaring tampilan. Semua pengguna aktif membaca dokumen dataset yang sama. Untuk isolasi data yang ketat, dataset perlu dipecah menjadi dokumen per pelanggan dengan rules masing-masing.
- Pertimbangkan **App Check** dan **Multi-factor authentication** (Identity Platform) untuk lapisan tambahan.

## Membuka tanpa Firebase Hosting
Isi `FALLBACK_CONFIG` di bagian bawah `public/index.html` dengan nilai dari **Project settings → Your apps → Web app (SDK setup and configuration → Config)**. Tambahkan domain hosting Anda di **Authentication → Settings → Authorized domains**.

## Memperbarui data periode berikutnya
Director/Finance membuka **11 · Data, Upload & Rekonsiliasi → Dataset resmi di Firebase** dan mengunggah file JSON baru dengan struktur yang sama. Setiap pembaruan tercatat di Audit Trail.
