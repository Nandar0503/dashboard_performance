// Konfigurasi Web App Firebase untuk project profitability-gov3.
// Ambil nilainya dari: Firebase Console → Project settings → General → Your apps → Web app
// → "SDK setup and configuration" → Config. Nilai ini memang dipakai di browser (bukan rahasia);
// keamanan data dijaga oleh firestore.rules dan login.
window.FIREBASE_CONFIG = {
  apiKey: "",            // ← isi
  authDomain: "profitability-gov3.firebaseapp.com",
  projectId: "profitability-gov3",
  storageBucket: "profitability-gov3.firebasestorage.app",
  messagingSenderId: "", // ← isi
  appId: ""              // ← isi
};
