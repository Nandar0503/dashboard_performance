# Profitability Command · Segment 3 — Supabase Realtime

Versi ini mempertahankan tampilan dan modul dashboard yang ada, menggunakan:
- **Firebase Authentication + Firestore** untuk login, profil/peran pengguna, dan audit trail yang sudah ada.
- **Supabase PostgreSQL + Realtime** untuk dataset profitability.
- **Google Sheets Apps Script** untuk sinkronisasi otomatis ke Supabase.

Alur data:

```text
Google Sheets
   │ Apps Script trigger (±1–2 menit)
   ▼
Supabase REST API → public.profitability_datasets
   │ Supabase Realtime (Postgres Changes)
   ▼
Dashboard GitHub Pages (tanpa refresh manual)
```

## File utama

| File | Fungsi |
|---|---|
| `dashboard_profitability_govseg3_2026.html` | Dashboard dan listener Supabase Realtime |
| `supabase-config.js` | Supabase Project URL + publishable key (boleh ada di browser) |
| `supabase-schema.sql` | Tabel, RLS, policy, helper function, dan Realtime publication |
| `apps-script/Code.gs` | Sinkronisasi sheet ke Supabase |
| `firebase-config.js` | Firebase Web config untuk login/profil lama |
| `firestore.rules` | Aturan Firestore untuk users dan audit lama |

## 1. Konfigurasi Supabase

1. Buka Supabase project `taxkvrjgotghclmpjqkg`.
2. Buka **SQL Editor → New query**.
3. Jalankan seluruh isi `supabase-schema.sql`.
4. Buka **Authentication → Sign In / Third-party Auth** (nama menu dapat berbeda), tambahkan provider **Firebase** dan masukkan Firebase Project ID: `profitability-gov3`.
5. Pastikan fitur Realtime aktif untuk tabel `public.profitability_datasets` (skrip SQL sudah menambahkannya ke publication `supabase_realtime`).

`supabase-config.js` sudah berisi Project URL dan publishable key yang diberikan. Publishable key boleh dipublikasikan; jangan pernah memasukkan Supabase secret/service_role key ke file ini.

### Daftarkan pengguna dashboard di Supabase

Login tetap menggunakan Firebase. Supabase RLS juga memeriksa Firebase UID melalui tabel `dashboard_access`, sehingga akun yang hanya punya URL dashboard tidak dapat membaca dataset.

Untuk setiap pengguna dashboard yang aktif:
1. Buka Firebase Console → Authentication → Users, salin UID pengguna.
2. Jalankan SQL berikut di Supabase SQL Editor dengan UID dan email yang benar:

```sql
insert into public.dashboard_access (user_id,email,display_name,role,active)
values ('FIREBASE_UID','email@instansi.go.id','Nama Pengguna','Director',true)
on conflict (user_id) do update
set email=excluded.email,
    display_name=excluded.display_name,
    role=excluded.role,
    active=excluded.active;
```

Peran yang diperbolehkan: `Director`, `Finance`, `Business Unit Head`, `Project Manager`, `Analyst`.
Hanya `Director` dan `Finance` yang dapat memperbarui dataset melalui fitur unggah dashboard. Pengguna `Sync` tidak perlu didaftarkan di tabel ini.

Saat pengguna dinonaktifkan atau dihapus, ubah `active=false` pada barisnya di `dashboard_access` juga. Perubahan peran di Firebase/Firestore tidak otomatis mengubah tabel Supabase.

## 2. Google Sheets → Supabase

1. Buka spreadsheet sumber.
2. Pilih **Extensions → Apps Script**.
3. Ganti isi `Code.gs` dengan file `apps-script/Code.gs` dari paket ini.
4. Simpan, lalu muat ulang spreadsheet. Menu **Profitability Sync** akan muncul.
5. Pilih **Profitability Sync → 1. Atur koneksi Supabase**.
6. Masukkan:
   - Project URL: `https://taxkvrjgotghclmpjqkg.supabase.co`
   - Supabase Secret Key: ambil dari Supabase Dashboard → Project Settings → API Keys → Secret key. Jika project masih memakai key lama, gunakan `service_role` hanya di Apps Script.
7. Pilih **Sinkronkan sekarang** untuk pengiriman pertama.
8. Jika berhasil, pilih **2. Aktifkan sinkron otomatis**.

Secret key disimpan di **Apps Script Script Properties**, bukan di Google Sheet, GitHub, atau browser. Jangan mengirimkan key tersebut ke chat atau memasukkannya ke source code. Apps Script mengirim data melalui Supabase REST API dengan hak server; RLS tetap melindungi akses dari browser.

Skrip membaca sheet yang sama seperti versi sebelumnya:
- `Summary`
- `Breakdown Pareto`
- `Rekap SAP S3`

Perubahan pada sheet dipantau dengan trigger dan dikirim dalam kisaran ±1–2 menit. Dashboard yang sedang terbuka menerima event Supabase Realtime tanpa reload.

## 3. Deploy ke GitHub Pages

1. Ekstrak ZIP.
2. Salin seluruh isi folder `dashboard_performance/` ke repository `nandar0503/dashboard_performance`, timpa file yang lama.
3. Commit dan push ke branch yang digunakan GitHub Pages.
4. Buka URL dashboard lama:

`https://nandar0503.github.io/dashboard_performance/dashboard_profitability_govseg3_2026.html`

URL dengan hash `#pengguna` tetap dapat digunakan. Browser cache dapat diatasi dengan hard refresh setelah deployment.

## 4. Pemeriksaan awal

- SQL schema sudah dijalankan.
- Firebase Third-Party Auth sudah dikonfigurasi di Supabase.
- UID pengguna dashboard sudah dimasukkan ke `dashboard_access`.
- Secret key Supabase sudah disimpan melalui menu Apps Script.
- Sinkronisasi pertama berhasil dan baris `segment3-ytd2026` muncul di `profitability_datasets`.
- Supabase Realtime sudah aktif.
- Dashboard menampilkan chip **Live** dan waktu pembaruan.

## Catatan keamanan

- `sb_publishable_...` memang dirancang untuk aplikasi browser, tetapi akses data tetap wajib dilindungi RLS.
- **Jangan** pernah menaruh `sb_secret_...` atau `service_role` key di `supabase-config.js`, HTML, GitHub, atau browser.
- Dataset berisi informasi keuangan. Jangan membuat policy `SELECT USING (true)` untuk role `anon`.
- File ZIP sebelumnya menyertakan konfigurasi Firebase Web. Firebase Web API key bukan secret; keamanan login tetap bergantung pada Firebase Auth dan Firestore Rules.
- Versi ini memindahkan dataset resmi ke Supabase, tetapi login, profil pengguna, dan audit trail lama masih menggunakan Firebase/Firestore.
