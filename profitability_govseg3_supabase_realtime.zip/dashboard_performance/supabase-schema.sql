-- Profitability Command · Segment 3
-- Jalankan di Supabase SQL Editor setelah mengaktifkan Firebase sebagai Third-Party Auth provider.
-- Tabel dataset hanya bisa dibaca oleh Firebase user yang tercantum aktif di dashboard_access.
-- Secret/service_role key hanya digunakan Apps Script dan tidak boleh diletakkan di browser.

create table if not exists public.dashboard_access (
  user_id text primary key,
  email text,
  display_name text,
  role text not null check (role in ('Director','Finance','Business Unit Head','Project Manager','Analyst')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profitability_datasets (
  id text primary key,
  payload jsonb not null,
  source text not null default 'Google Sheets',
  client_count integer not null default 0,
  updated_by text,
  hash text,
  updated_at timestamptz not null default now()
);

create or replace function public.is_profitability_user()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.dashboard_access a
    where a.user_id = (auth.jwt() ->> 'sub')
      and a.active = true
  );
$$;

create or replace function public.is_profitability_writer()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.dashboard_access a
    where a.user_id = (auth.jwt() ->> 'sub')
      and a.active = true
      and a.role in ('Director','Finance')
  );
$$;

revoke all on function public.is_profitability_user() from public;
revoke all on function public.is_profitability_writer() from public;
grant execute on function public.is_profitability_user() to authenticated;
grant execute on function public.is_profitability_writer() to authenticated;

alter table public.dashboard_access enable row level security;
alter table public.profitability_datasets enable row level security;

drop policy if exists "Users can read own access row" on public.dashboard_access;
create policy "Users can read own access row"
on public.dashboard_access for select to authenticated
using (user_id = (auth.jwt() ->> 'sub'));

drop policy if exists "Active dashboard users read dataset" on public.profitability_datasets;
create policy "Active dashboard users read dataset"
on public.profitability_datasets for select to authenticated
using (public.is_profitability_user());

drop policy if exists "Finance and Director update dataset" on public.profitability_datasets;
create policy "Finance and Director update dataset"
on public.profitability_datasets for insert to authenticated
with check (public.is_profitability_writer());

drop policy if exists "Finance and Director edit dataset" on public.profitability_datasets;
create policy "Finance and Director edit dataset"
on public.profitability_datasets for update to authenticated
using (public.is_profitability_writer())
with check (public.is_profitability_writer());

grant select on public.dashboard_access to authenticated;
grant select on public.profitability_datasets to authenticated;
grant insert, update on public.profitability_datasets to authenticated;

-- Enable Realtime events for dataset table.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'profitability_datasets'
  ) then
    alter publication supabase_realtime add table public.profitability_datasets;
  end if;
end $$;

-- After creating Firebase users, add their Firebase UID to dashboard_access.
-- Example (replace values with the real Firebase UID and email):
-- insert into public.dashboard_access (user_id,email,display_name,role,active)
-- values ('FIREBASE_UID_HERE','finance@example.com','Finance User','Finance',true)
-- on conflict (user_id) do update set email=excluded.email, role=excluded.role, active=excluded.active;
