// Konfigurasi publik Supabase. Publishable key memang digunakan di browser.
// Keamanan dataset ditentukan oleh Third-Party Auth (Firebase) + RLS pada Supabase.
window.SUPABASE_CONFIG = {
  url: 'https://taxkvrjgotghclmpjqkg.supabase.co',
  publishableKey: 'sb_publishable_6lP1HjPMWVJvaWgIgB1YUg_QZgcZWvS'
};
